# yolobit_extension_ai_camera
Mục mở rộng để làm việc với AI Camera
